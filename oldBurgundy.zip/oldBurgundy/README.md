

# Project "OldBurgundy"

The color old burgundy is a dark tone of burgundy. The first recorded use of old burgundy as a color name in English was in 1926.

# Team Members

* Pablo Oliver Remón (leader)
* Jorge Izquierdo Bueno
* Ismael Artero Gasca
