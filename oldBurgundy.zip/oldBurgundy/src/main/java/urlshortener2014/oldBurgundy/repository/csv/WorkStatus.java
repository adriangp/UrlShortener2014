package urlshortener2014.oldBurgundy.repository.csv;

public enum WorkStatus {
	INCOMING, PENDING, FAIL, OK
}
