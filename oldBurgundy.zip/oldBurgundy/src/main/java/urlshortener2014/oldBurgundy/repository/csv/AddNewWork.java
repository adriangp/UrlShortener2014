package urlshortener2014.oldBurgundy.repository.csv;

public interface AddNewWork {

	public boolean addIncomingWork(Work work);
	
}
